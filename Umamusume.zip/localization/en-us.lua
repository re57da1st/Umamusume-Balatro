return {
    descriptions = {
        Back = {
            b_uma_ura = {
                name = "URA Deck",
                text = {
                    "All {C:uma_rainbow}Uma{}-related items",
                    "appear {C:attention}2X{} more often"
                }
            },

            b_uma_legendary = {
                name = "Legendary deck",
                text = {
                    "{C:common}Common{} jokers are",
                    "{C:red}3X{} as common",
                    "{C:legendary}Legendary{} jokers can",
                    "appear in the shop",
                    --"{C:common}84{}/{C:uncommon}10{}/{C:rare}4{}/{C:legendary}2",
                }
            },
        },

        Joker = {
            j_uma_spacer = {
                name = "Spacer",
                text = {
                    "This joker is a spacer joker",
                    "It's only here to separate",
                    "joker rarities in a challenge",
                },
            },

            j_uma_helios = {
                name = "Daitaku Helios",
                text = {
                    {
                        "{C:clubs}Clubs{} and {C:diamonds}Diamonds{} give",
                        "{X:mult,C:white}X#1#{} Mult when scored",
                        "{C:inactive}Wei Wei!!!{}"
                    }
                },
            },

            j_uma_daiwa = {
                name = "Daiwa Scarlet",
                text = {
                    {
                        "Adds {C:mult}+#1#{} Mult to played",
                        "hand's base mult for every",
                        "{C:attention}Queen{} in your deck",
                    "{C:inactive}(Currently {C:mult}+#2#{}{C:inactive})",
                    }
                },
            },

            j_uma_agnes = {
                name = "Agnes Digital",
                text = {
                    "All played {C:attention}Kings{} and",
                    "{C:attention}Jacks{} become {C:hearts}Queens{}",
                    "when scored"
                },
            },

            j_uma_turbo = {
                name = "Twin Turbo",
                text = {
                    "This Joker gains {C:mult}+#1#{} Mult",
                    "and levels up {C:attention}played hand",
                    "if played hand contains",
                    "a {C:attention}#2#",
                    "{C:inactive}(Currently {C:red}+#3#{C:inactive} Mult)",
                },
            },

            j_uma_goldship = {
                name = "Goldship",
                text = {
                    "{C:mult}+#1# {}to {C:mult}+#2# {}mult range",
                    "Mimics a certain {C:attention}boss blind",
                    "{C:inactive}>> #3# <<"
                },
            },

            j_uma_oguri = {
                name = "Oguri Cap",
                text = {
                    "On round end, {C:attention}consume{} the",
                    "{C:attention}lowest{} rank card held in",
                    "hand, and gain {C:chips}+#2#{} chips",
                    "{C:inactive}(Currently {C:chips}+#1#{C:inactive} Chips)"
                },
            },

            j_uma_bakushin = {
                name = "Sakura Bakushin O",
                text = {
                    
                    "{C:uma_col_bakushin}+#3# Speed{} at round begin,",
                    "lose {C:uma_col_bakushin}-#4# Speed{} every {C:attention}#6#{} second(s).",
                    "Add {C:uma_col_bakushin}Speed{} to {C:mult}Mult{} at round end.",
                    "{C:inactive}(Mult: {C:mult}+#1#{C:inactive}, Speed: {C:uma_col_bakushin}#2#{C:inactive})",
                },
            },

            j_uma_mambo = {
                name = "Matikanetannhauser",
                text = {
                    "Gives {C:chips}+#1#{} Chips and {C:mult}+#2# {X:mult,C:white}X#3#{}",
                    " Mult. Using {C:attention}certain consumables{}",
                    " increase these values"
                },
            },

            j_uma_chiyono = {
                name = "Sakura Chiyono O",
                text = {
                    "Converts a played {C:uma_turf}Turf",
                    "card to a {C:uma_blossom}Blossom {}card",
                    "after scoring",
                    "{C:inactive}(max 1 per hand)"
                },
            },

            j_uma_norn = {
                name = "Norn Ace",
                text = {
                    "Earn {C:money}$#1#{} per {C:uma_rainbow}Uma",
                    "joker at end of round",
                    "{C:inactive}(currently {C:money}$#2#{C:inactive})",
                },
            },

            j_uma_obey = {
                name = "Obey Your Master",
                text = {
                    "Every played {C:attention}card{}",
                    "permanently gains",
                    "{C:mult}+#1#{} Mult when scored",
                },
            },

            j_uma_fuku = {
                name = "Matikanefukukitaru",
                text = {
                    "If final score is {C:attention}x#1# {}blind",
                    "size, create a {C:uma_col_better_tarot2}Tarot+{} card,",
                    "else create a {C:uma_col_worse_tarot2}Tarot-{} card"
                },
            },

            j_uma_love = {
                name = "{C:hearts}Still in Love",
                text = {
                    "#1# {C:hearts}Pure Hearts{},",
                    "#2#",
                    "{C:inactive}(#3#)"
                },
            },

            j_uma_vodka = {
                name = "Vodka",
                text = {
                    "Every played {C:attention}Queen{}",
                    "permanently gains",
                    "{C:chips}+#2#{} Chips and {C:mult}+#1#{} Mult",
                    "when scored"
                },
            },

            j_uma_teio = {
                name = "Tokai Teio",
                text = {
                    "{X:mult,C:white}X#5#{} Mult",
                    "{C:green}#1# in #2#{} chance to {C:red}self-debuff{}",
                    "restores after {C:attention}2 {}blinds",
                    "value multiplies by {X:mult,C:white}X#6#",
                    "{C:inactive}({C:attention}#4# {C:inactive}debuffs left)",
                },
            },

            j_uma_haru = {
                name = "Haru Urara",
                text = {
                    "{C:green}#1# in #2#{} chance",
                    "to retrigger each",
                    "played {C:attention}dirt{} card",
                },
            },

            j_uma_mini = {
                name = "Mini the Lady",
                text = {
                "On {C:attention}final hand{} of round,",
                "if current score is less",
                "than {C:attention}#2#%{} of blind size,",
                "reduce blind size by {C:attention}#1#%{}"
                },
            },

            j_uma_creek = {
                name = "Super Creek",
                text = {
                    "BIIIIIIIG stuff",
                    "{C:inactive}This message was brought to you by Frisk{}"
                },
            },

            j_uma_air = {
                name = "Air Groove",
                text = {
                    "If your full deck is >{C:attention}#1#%{}/{X:attention,C:white}#2#%{}",
                    "{C:enhanced}Enhanced{} cards, new Playing cards",
                    "will be {C:enhanced}Enhanced{} {C:attention}#3#%{}/{X:attention,C:white}#4#%{} more often",
                    "{C:inactive}(Currently {V:1,B:2}#5#{C:inactive}/#6#)"
                },
            },

            j_uma_nature = {
                name = "Nice Nature",
                text = {
                    "Allows you to {C:uma_banish,E:1}Banish{}",
                    "bought jokers, which will",
                    "no longer appear normally",
                },
            },

            j_uma_maruzensky = {
                name = "Maruzensky",
                text = {
                    "{C:attention}Double{} hand size,",
                    "max hands capped at {C:blue}#1#{}"
                },
            },

            j_uma_rudolf = {
                name = "Symboli Rudolf",
                text = {
                    "Gains {C:chips}+#1#{} chips for",
                    "every {C:attention}round{} passed",
                    "Beating a {C:attention}Boss Blind",
                    "multiplies stored chips",
                    "by {C:attention}X#2#{}",
                    "{C:inactive}(currently {C:chips}+#3#{C:inactive})",
                },
            },

            j_uma_tamamo = {
                name = "Tamamo Cross",
                text = {
                    "stuff",
                },
            },

            j_uma_doto = {
                name = "Meisho Doto",
                text = {
                    "Gives {C:chips}+#1#{} Chips and {C:mult}+#2#{} Mult",
                    "Increases by {C:chips}+#3#{} and {C:mult}+#4#{}",
                    "when {C:attention}Boss Blind{} defeated"
                },
            },

            j_uma_bourbon = {
                name = "Mihono Bourbon",
                text = {
                    "stuff",
                },
            },

            j_uma_belno = {
                name = "Belno Light",
                text = {
                    "Every {C:attention}#1#{} rounds, adds",
                    "a {C:uma_retrigger}retrigger{} to a random",
                    "{C:blue}blueprint compatible{} joker",
                    "{C:inactive}({C:attention}#2# {C:inactive}rounds left)"
                },
            },

            j_uma_vivlos = {
                name = "Vivlos",
                text = {
                    "All scoring cards gain",
                    "a {C:uma_wealth}Wealth{} sticker",
                },
            },

            j_uma_neo = {
                name = "Neo Universe",
                text = {
                    "Create a {C:planet}Planet{} card",
                    "when {C:attention}Blind{} is selected",
                    "{C:inactive}(Must have room)",
                },
            },

            j_uma_lilac = {
                name = "Lucky Lilac",
                text = {
                    "{C:green}#1# in #2#{} chance for",
                    "{C:attention}lucky{} cards to give",
                    "{C:blue}#3#{} Chips when scored",
                },
            },

            j_uma_tact = {
                name = "Daring Tact",
                text = {
                    "Gives {C:mult}+#1#{} Mult for",
                    "every {C:uma_turf}Spread{} and {C:uma_blossom}Bloom{}",
                    "triggered this run",
                    "{C:inactive}(currently {C:mult}+#2#{C:inactive} Mult)",
                },
            },

            j_uma_opera = {
                name = "T.M. Opera O",
                text = {
                    "All blinds are",
                    "considered {C:attention}Boss Blinds",
                    "({C:red}2X{} Base size, {C:money}$5{} payout)",
                },
            },

            j_uma_ebeyan = {
                name = "Forever Young",
                text = {
                    "Each {C:attention}Ace{} and {C:uma_dirt}Dirt{} card",
                    "gives {X:mult,C:white}X#1#{} Mult when",
                    "scored or held in hand",
                },
            },

            j_uma_g_city = {
                name = "Gold City",
                text = {
                    "Pay {C:money}$#1#{} to",
                    "add a card",
                    "to your hand",
                },
            },

            j_uma_aruvu = {
                name = "Admire Groove",
                text = {
                    "Gain {C:mult}+#1#{} Mult for each",
                    "{C:clubs}Club{} card {C:attention}played and scored{},",
                    "{C:mult}-#2#{} Mult for other suits",
                    "{C:inactive}(Currently {C:mult}+#3# {C:inactive}Mult)",
                },
            },

            j_uma_retrigger = {
                name = "Retrigger",
                text = {
                    "{C:uma_retrigger}#1# extra trigger",
                },
            },

            j_uma_retriggers = {
                name = "Retriggers",
                text = {
                    "{C:uma_retrigger}#1# extra triggers",
                },
            },

            j_uma_tachyon = {
                name = "Agnes Tachyon",
                text = {
                    "Guarantees all {C:attention}listed",
                    "{C:green,E:1,S:1.1}probabilities",
                    "{C:inactive}(ex: {C:green}1 in 7{C:inactive} -> {C:green}7 in 7{C:inactive})",
                },
            },

            j_uma_rickey = {
                name = "Copano Rickey",
                text = {
                    "stuff",
                },
            },

            j_uma_almond = {
                name = "Almond Eye",
                text = {
                    "This Joker gains {X:red,C:white}X#1#{} Mult when",
                    "playing a {C:attention}Hidden hand{}, resets",
                    " when playing a {C:attention}Normal hand{}",
                    "{C:inactive}(Currently {X:red,C:white}X#2#{C:inactive} Mult)"
                },
            },

            j_uma_mayano = {
                name = "Mayano Top Gun",
                text = {
                    'Once per blind, {C:attention}"Swap"{} to',
                    "swap {C:blue}hands{} and {C:red}discards{} left",
                    "{C:attention}Automatically{} triggers",
                    "to prevent death",
                },
            },

            j_uma_festa = {
                name = "Nakayama Festa",
                text = {
                    "Beating a {C:attention}Boss Blind",
                    "changes the ante",
                    "by either {C:attention}0{} or {C:attention}2"
                },
            },

            j_uma_dober = {
                name = "Mejiro Dober",
                text = {
                    "{X:mult,C:white}X6{} Mult if {C:attention}all{} jokers",
                    "are {C:uma_rainbow}Uma{} jokers",
                },
            },

            j_uma_orfevre = {
                name = "Orfevre",
                text = {
                    "Gives {C:chips}+#1#{} Chips and {C:mult}+#2# {X:mult,C:white}X#3#{} Mult",
                    "for every {C:uma_rainbow}Uma{} joker that has placed",
                    "{C:attention}Top 3{} in {C:chips}<#4#%{}/{C:mult}>#4#%{}/{X:mult,C:white}#5#%{} of their races",
                    "{C:inactive}(Currently {C:chips}+#6# {C:mult}+#7# {X:mult,C:white}X#8#{C:inactive})"
                },
            },

            j_uma_donna = {
                name = "Gentildonna",
                text = {
                    "{C:green}1 in 4{} chance to {C:attention}destroy",
                    "an {C:uma_rainbow}Uma{} joker who has",
                    "a worse {C:attention}Top 3{} ratio",
                    "than herself"
                },
            },

            j_uma_transcend = {
                name = "Transcend",
                text = {
                    "stuff"
                },
            },

            j_uma_feno = {
                name = "Fenomeno",
                text = {
                    "{C:dark_edition}+1{} Joker slot",
                    "{C:green}1 in 4{} chance to",
                    "{X:uma_feno,C:white}Intimidate{} each",
                    "{C:uma_rainbow}Uma{} joker"
                },
            },

            j_uma_desire = {
                name = "Red Desire",
                text = {
                    "{C:attention}Prevents{} card debuffs",
                    "Copies cards that are",
                    "Destroyed {C:attention}2{} times"
                },
            },

            j_uma_XYZ = {
                name = "XYZ",
                text = {
                    "{C:dark_edition}+5{} Joker slots",
                    "All jokers in the",
                    "shop are {C:common}Common"
                },
            },

            j_uma_curren = {
                name = "Curren Chan",
                text = {
                    "stuff"
                },
            },

            j_uma_slotmachine = {
                name = "Slot Machine",
                text = {
                    "Rolls {C:attention}3{} cards from your deck",
                    "Gives {X:mult,C:white}X1{} extra mult for each",
                    "scoring card that matches",
                    "{C:inactive}(Default {X:mult,C:white}X1{C:inactive})"
                },
            },
        },

        Planet = {
            c_uma_twin_moons = {
                name = "Twin Moons",
                text = {
                    "({V:1}lvl.#1#{}) Level up",
                    "{C:attention}#2#",
                    "{C:mult}+#3#{} Mult and",
                    "{C:chips}+#4#{} chips",
                },
            }

        },

        Blind = {
            bl_uma_frisk_blind = {
                name = "Frisk's Blind",
                text = {
                    "Increases blind size by 25%",
                    "after each hand played",
                },
            },
        },

        fuku_cards = {
            c_uma_better_chariot = {
                name = "The Chariot{C:green}+",
                text = {
                    "Enhances {C:attention}#1#{} selected",
                    "card into a",
                    "{C:attention}#2#",
                },
            },
            c_uma_better_death = {
                name = "Death{C:green}+",
                text = {
                    "Select {C:attention}#1#{} cards,",
                    "convert the {C:attention}left{} cards",
                    "into the {C:attention}right{} card",
                    "{C:inactive}(Drag to rearrange)",
                },
            },
            c_uma_better_devil = {
                name = "The Devil{C:green}+",
                text = {
                    "Enhances {C:attention}#1#{} selected",
                    "card into a",
                    "{C:attention}#2#",
                },
            },
            c_uma_better_emperor = {
                name = "The Emperor{C:green}+",
                text = {
                    "Creates up to {C:attention}#1#",
                    "random {C:spectral}Spectral{} cards",
                    "{C:inactive}(Must have room)",
                },
            },
            c_uma_better_empress = {
                name = "The Empress{C:green}+",
                text = {
                    "Enhances {C:attention}#1#",
                    "selected cards to",
                    "{C:attention}#2#s",
                },
            },
            c_uma_better_fool = {
                name = "The Fool{C:green}+",
                text = {
                    "Creates the last",
                    "{C:spectral}Spectral{}/{C:tarot}Tarot{} and {C:planet}Planet{} card",
                    "used during this run",
                    "{s:0.8,C:tarot}The Fools{s:0.8} excluded",
                },
            },
            c_uma_better_hanged_man = {
                name = "The Hanged Man{C:green}+",
                text = {
                    "Destroys up to",
                    "{C:attention}#1#{} selected cards",
                },
            },
            c_uma_better_heirophant = {
                name = "The Hierophant{C:green}+",
                text = {
                    "Enhances {C:attention}#1#",
                    "selected cards to",
                    "{C:attention}#2#s",
                },
            },
            c_uma_better_hermit = {
                name = "The Hermit{C:green}+",
                text = {
                    "Doubles money",
                    "{C:inactive}(Max of {C:money}$#1#{C:inactive})",
                },
            },
            c_uma_better_high_priestess = {
                name = "The High Priestess{C:green}+",
                text = {
                    "Creates up to {C:attention}#1#{} random",
                    "{C:uma_col_better_planet2}Better Planet{} cards",
                    "{C:inactive}(Must have room)",
                },
            },
            c_uma_better_judgement = {
                name = "Judgement{C:green}+",
                text = {
                    "Creates a random",
                    "{C:red}Rare{} {C:attention}Joker{} card",
                    "{C:inactive}(Must have room)",
                },
            },
            c_uma_better_justice = {
                name = "Justice{C:green}+",
                text = {
                    "Enhances {C:attention}#1#{} selected",
                    "card into a",
                    "{C:attention}#2#",
                },
            },
            c_uma_better_lovers = {
                name = "The Lovers{C:green}+",
                text = {
                    "Enhances {C:attention}#1#{} selected",
                    "card into a",
                    "{C:attention}#2#",
                },
            },
            c_uma_better_magician = {
                name = "The Magician{C:green}+",
                text = {
                    "Enhances {C:attention}#1#{} selected cards to",
                    "{C:attention}#2#s",
                },
            },
            c_uma_better_moon = {
                name = "The Moon{C:green}+",
                text = {
                    "Converts up to",
                    "{C:attention}#1#{} selected cards",
                    "to {V:1}#2#{}",
                },
            },
            c_uma_better_star = {
                name = "The Star{C:green}+",
                text = {
                    "Converts up to",
                    "{C:attention}#1#{} selected cards",
                    "to {V:1}#2#{}",
                },
            },
            c_uma_better_strength = {
                name = "Strength{C:green}+",
                text = {
                    "Increases rank of",
                    "up to {C:attention}#1#{} selected",
                    "cards by {C:attention}1",
                },
            },
            c_uma_better_sun = {
                name = "The Sun{C:green}+",
                text = {
                    "Converts up to",
                    "{C:attention}#1#{} selected cards",
                    "to {V:1}#2#{}",
                },
            },
            c_uma_better_temperance = {
                name = "Temperance{C:green}+",
                text = {
                    "Gives the total sell",
                    "value of all current",
                    "Jokers {C:inactive}(Max of {C:money}$#1#{C:inactive})",
                    "{C:inactive}(Currently {C:money}$#2#{C:inactive})",
                },
            },
            c_uma_better_tower = {
                name = "The Tower{C:green}+",
                text = {
                    "Enhances {C:attention}#1#{} selected",
                    "card into a",
                    "{C:attention}#2#",
                },
            },
            c_uma_better_wheel_of_fortune = {
                name = "The Wheel of Fortune{C:green}+",
                text = {
                    "{C:green}#1# in #2#{} chance to add",
                    "{C:dark_edition}Holographic{} or",
                    "{C:dark_edition}Polychrome{} edition",
                    "to a random {C:attention}Joker",
                },
            },
            c_uma_better_world = {
                name = "The World{C:green}+",
                text = {
                    "Converts up to",
                    "{C:attention}#1#{} selected cards",
                    "to {V:1}#2#{}",
                },
            },





            c_uma_worse_chariot = {
                name = "The Chariot{C:red}-",
                text = {
                    "{C:green}#2# in #3#{} chance to",
                    "enhance {C:attention}#1#{} selected",
                    "card into a {C:attention}#4#",
                },
            },
            c_uma_worse_death = {
                name = "Death{C:red}-",
                text = {
                    "Select {C:attention}#1#{} cards,",
                    "convert the {C:attention}left{} cards",
                    "into the {C:attention}right{} card",
                    "{C:inactive}(Drag to rearrange)",
                },
            },
            c_uma_worse_devil = {
                name = "The Devil{C:red}-",
                text = {
                    "{C:green}#2# in #3#{} chance to",
                    "enhance {C:attention}#1#{} selected",
                    "card into a {C:attention}#4#",
                },
            },
            c_uma_worse_emperor = {
                name = "The Emperor{C:red}-",
                text = {
                    "Creates {C:attention}#1# random",
                    "{C:uma_col_worse_tarot}Worse Tarot{} card",
                    "{C:inactive}(Must have room)",
                },
            },
            c_uma_worse_empress = {
                name = "The Empress{C:red}-",
                text = {
                    "Enhances {C:attention}#1#{} selected",
                    "card to {C:attention}#2#s",
                },
            },
            c_uma_worse_fool = {
                name = "The Fool{C:red}-",
                text = {
                    "Creates the last",
                    "{C:tarot}Tarot{} or {C:planet}Planet{} card",
                    "used during this run",
                    "{s:0.8,C:tarot}The Fool{s:0.8} excluded",
                },
            },
            c_uma_worse_hanged_man = {
                name = "The Hanged Man{C:red}-",
                text = {
                    "Destroys {C:attention}#1#{} selected card",
                },
            },
            c_uma_worse_heirophant = {
                name = "The Hierophant{C:red}-",
                text = {
                    "Enhances {C:attention}#1#{} selected",
                    "card to {C:attention}#2#s",
                },
            },
            c_uma_worse_hermit = {
                name = "The Hermit{C:red}-",
                text = {
                    "Doubles money",
                    "{C:inactive}(Max of {C:money}$#1#{C:inactive})",
                },
            },
            c_uma_worse_high_priestess = {
                name = "The High Priestess{C:red}-",
                text = {
                    "Creates up to {C:attention}#1#",
                    "random {C:planet}Planet{} cards",
                    "{C:inactive}(Must have room)",
                },
            },
            c_uma_worse_judgement = {
                name = "Judgement{C:red}-",
                text = {
                    "Creates a random",
                    "{C:red}Rare{} {C:attention}Joker{} card",
                    "{C:inactive}(Must have room)",
                },
            },
            c_uma_worse_justice = {
                name = "Justice{C:red}-",
                text = {
                    "{C:green}#2# in #3#{} chance to",
                    "enhance {C:attention}#1#{} selected",
                    "card into a {C:attention}#4#",
                    "else, {C:attention}destroy{} selected card"
                },
            },
            c_uma_worse_lovers = {
                name = "The Lovers{C:red}-",
                text = {
                    "{C:green}#2# in #3#{} chance to",
                    "enhance {C:attention}#1#{} selected",
                    "card into a {C:attention}#4#",
                },
            },
            c_uma_worse_magician = {
                name = "The Magician{C:red}-",
                text = {
                    "Enhances {C:attention}#1#{} selected",
                    "card to {C:attention}#2#s",
                },
            },
            c_uma_worse_moon = {
                name = "The Moon{C:red}-",
                text = {
                    "Converts {C:attention}#1#{} selected ",
                    "card to {V:1}#2#{}",
                },
            },
            c_uma_worse_star = {
                name = "The Star{C:red}-",
                text = {
                    "Converts {C:attention}#1#{} selected ",
                    "card to {V:1}#2#{}",
                },
            },
            c_uma_worse_strength = {
                name = "Strength{C:red}-",
                text = {
                    "Increases rank of",
                    "{C:attention}#1#{} selected card by {C:attention}1",
                },
            },
            c_uma_worse_sun = {
                name = "The Sun{C:red}-",
                text = {
                    "Converts {C:attention}#1#{} selected ",
                    "card to {V:1}#2#{}",
                },
            },
            c_uma_worse_temperance = {
                name = "Temperance{C:red}-",
                text = {
                    "Gives the total sell",
                    "value of all current",
                    "Jokers {C:inactive}(Max of {C:money}$#1#{C:inactive})",
                    "{C:inactive}(Currently {C:money}$#2#{C:inactive})",
                },
            },
            c_uma_worse_tower = {
                name = "The Tower{C:red}-",
                text = {
                    "{C:green}#2# in #3#{} chance to",
                    "enhance {C:attention}#1#{} selected",
                    "card into a {C:attention}#4#",
                },
            },
            c_uma_worse_wheel_of_fortune = {
                name = "The Wheel of Fortune{C:red}-",
                text = {
                    "{C:green}#1# in #2#{} chance to add {C:dark_edition}Foil{}",
                    "edition to a random {C:attention}Joker",
                },
            },
            c_uma_worse_world = {
                name = "The World{C:red}-",
                text = {
                    "Converts {C:attention}#1#{} selected ",
                    "card to {V:1}#2#{}",
                },
            },





            c_uma_better_mercury = {
                name = "Mercury{C:green}+",
                text = {
                    "({V:1}lvl.#1#{}) Level up",
                    "{C:attention}#2#{} 3 times",
                    "{C:mult}+#5#{} Mult and",
                    "{C:chips}+#6#{} chips",
                },
            },

            c_uma_better_venus = {
                name = "Venus{C:green}+",
                text = {
                    "({V:1}lvl.#1#{}) Level up",
                    "{C:attention}#2#{} 3 times",
                    "{C:mult}+#5#{} Mult and",
                    "{C:chips}+#6#{} chips",
                },
            },

            c_uma_better_earth = {
                name = "Earth{C:green}+",
                text = {
                    "({V:1}lvl.#1#{}) Level up",
                    "{C:attention}#2#{} 3 times",
                    "{C:mult}+#5#{} Mult and",
                    "{C:chips}+#6#{} chips",
                },
            },

            c_uma_better_mars = {
                name = "Mars{C:green}+",
                text = {
                    "({V:1}lvl.#1#{}) Level up",
                    "{C:attention}#2#{} 3 times",
                    "{C:mult}+#5#{} Mult and",
                    "{C:chips}+#6#{} chips",
                },
            },

            c_uma_better_jupiter = {
                name = "Jupiter{C:green}+",
                text = {
                    "({V:1}lvl.#1#{}) Level up",
                    "{C:attention}#2#{} 3 times",
                    "{C:mult}+#5#{} Mult and",
                    "{C:chips}+#6#{} chips",
                },
            },

            c_uma_better_saturn = {
                name = "Saturn{C:green}+",
                text = {
                    "({V:1}lvl.#1#{}) Level up",
                    "{C:attention}#2#{} 3 times",
                    "{C:mult}+#5#{} Mult and",
                    "{C:chips}+#6#{} chips",
                },
            },

            c_uma_better_uranus = {
                name = "Uranus{C:green}+",
                text = {
                    "({V:1}lvl.#1#{}) Level up",
                    "{C:attention}#2#{} 3 times",
                    "{C:mult}+#5#{} Mult and",
                    "{C:chips}+#6#{} chips",
                },
            },

            c_uma_better_neptune = {
                name = "Neptune{C:green}+",
                text = {
                    "({V:1}lvl.#1#{}) Level up",
                    "{C:attention}#2#{} 3 times",
                    "{C:mult}+#5#{} Mult and",
                    "{C:chips}+#6#{} chips",
                },
            },

            c_uma_better_pluto = {
                name = "Pluto{C:green}+",
                text = {
                    "({V:1}lvl.#1#{}) Level up",
                    "{C:attention}#2#{} 3 times",
                    "{C:mult}+#5#{} Mult and",
                    "{C:chips}+#6#{} chips",
                },
            },

            c_uma_better_planet_x = {
                name = "Planet X{C:green}+",
                text = {
                    "({V:1}lvl.#1#{}) Level up",
                    "{C:attention}#2#{} 3 times",
                    "{C:mult}+#5#{} Mult and",
                    "{C:chips}+#6#{} chips",
                },
            },

            c_uma_better_ceres = {
                name = "Ceres{C:green}+",
                text = {
                    "({V:1}lvl.#1#{}) Level up",
                    "{C:attention}#2#{} 3 times",
                    "{C:mult}+#5#{} Mult and",
                    "{C:chips}+#6#{} chips",
                },
            },

            c_uma_better_eris = {
                name = "Eris{C:green}+",
                text = {
                    "({V:1}lvl.#1#{}) Level up",
                    "{C:attention}#2#{} 3 times",
                    "{C:mult}+#5#{} Mult and",
                    "{C:chips}+#6#{} chips",
                },
            },

            c_uma_better_twin_moons = {
                name = "Twin Moons{C:green}+",
                text = {
                    "({V:1}lvl.#1#{}) Level up",
                    "{C:attention}#2#{} 3 times",
                    "{C:mult}+#5#{} Mult and",
                    "{C:chips}+#6#{} chips",
                },
            }
        },

        uma_ccs = {
            c_uma_mambo_boots = {
                name = "Mambo's Boots",
                text = {
                    "{C:attention}LOST AND FOUND:",
                    "Return boots to {C:uma_col_mambo2}Mambo{} and",
                    "gain {C:chips}+#1#{} Chips!"
                },
            },
            c_uma_mambo_hat = {
                name = "Mambo's Hat",
                text = {
                    "{C:attention}LOST AND FOUND:",
                    "Return hat to {C:uma_col_mambo2}Mambo{} and",
                    "gain {C:mult}+#1#{} Mult!"
                },
            },
            c_uma_mambo_plushie = {
                name = "Mambo's Plushie",
                text = {
                    "{C:attention}LOST AND FOUND:",
                    "Return plushie to {C:uma_col_mambo2}Mambo{} and",
                    "gain {X:mult,C:white}x#1#{} Mult!"
                },
            },





            c_uma_posterity = {
                name = "Posterity",
                text = {
                    "Combine {C:attention}2{} cards together,",
                    "adding their ranks",
                    "and all {C:attention}modifiers{}",
                    "{C:inactive}(Aces are considered low)"
                },
            },

            c_uma_pedigree = {
                name = "Pedigree",
                text = {
                    "Split {C:attention}1{} card into {C:attention}2{},",
                    "totaling the original rank",
                    "and distributing all {C:attention}modifiers{}",
                    "{C:inactive}(Aces are considered high)",
                },
            },





            c_uma_ssr_ticket = {
                name = "SSR Ticket",
                text = {
                    "Choose {C:attention}any{} {C:uma_rainbow}Uma{} Joker",
                    "to create",
                    "{C:inactive}(Must have room){}"
                },
            },
        },

        Enhanced = {
            m_uma_turf = {
                name = "Turf Card",
                text = {
                    "{X:chips,C:white}x#1#{} chips",
                    "spreads {C:uma_turf}Turf {}to blank playing",
                    "cards when {C:attention}scored together",
                    "{C:inactive}(max 1 spread per hand)"
                },
            },

            m_uma_blossom = {
                name = "Blossom Card",
                text = {
                    "{X:chips,C:white}x#1#{} chips",
                    "spreads {C:uma_turf}Turf {}to blank playing",
                    "cards when {C:attention}scored together",
                    "{C:inactive}(max 1 spread per hand)"
                },
            },

            m_uma_mossy = {
                name = "Mossy Card",
                text = {
                    "{C:chips}+#1#{} chips",
                    "no rank or suit",
                },
            },

            m_uma_dirt = {
                name = "Dirt Card",
                text = {
                    "Gives {C:mult}Mult{} equal to",
                    "number of {C:uma_dirt}Dirt{} cards",
                    "scored in this {C:attention}hand{}",
                    "Always scores"
                },
            }
        },

        Other = {
            undiscovered_uma_better_tarot = {
                name = "Not Discovered",
                text = {
                    "Purchase or use",
                    "this card in an",
                    "unseeded run to",
                    "learn what it does",
                },
            },
            
            undiscovered_uma_mambo_consumable = {
                name = "Not Discovered",
                text = {
                    "Purchase or use",
                    "this card in an",
                    "unseeded run to",
                    "learn what it does",
                },
            },

            uma_pure_hearts = {
                name = "{C:hearts}Pure Hearts",
                text = {
                    "#1#",
                    "#2# {C:attention}#3# {C:hearts}#4#{},",
                    "#5#",
                    
                    --[[
                    "A playing card",
                    "that is {C:attention}only {C:hearts}hearts{},",
                    "and nothing else",
                    ]]
                }
            },

            uma_scare = {
                name = "{X:uma_feno,C:white}Intimidate",
                text = {
                    "A debuff that",
                    "only lasts 1 hand",
                    
                    --[[
                    "A playing card",
                    "that is {C:attention}only {C:hearts}hearts{},",
                    "and nothing else",
                    ]]
                }
            },

            uma_retriggers = {
                name = "Retriggers",
                text = {
                    "#1#"
                }
            },

            uma_race_stats = {
                name = "Placings:",
                text = {
                    "1st: {C:attention}#1#",
                    "2nd: {C:attention}#2#",
                    "3rd: {C:attention}#3#",
                    "Total: {C:attention}#4#{} races"
                }
            },

            uma_race_stats_renamed = {
                name = "Placings:",
                text = {
                    "{C:inactive}(#5#)",
                    "1st: {C:attention}#1#",
                    "2nd: {C:attention}#2#",
                    "3rd: {C:attention}#3#",
                    "Total: {C:attention}#4#{} races"
                }
            },

            uma_race_stats_no_record = {
                name = "Placings:",
                text = {
                    "No Race Record"
                }
            },

            uma_turf_related = {
                name = "Turf-related",
                text = {
                    "All cards will have one",
                    "of the following enhancements:",
                    "{C:uma_turf}Turf{}, Dirt, Mossy, {C:uma_blossom}Blossom{}",
                    
                    --[[
                    "A playing card",
                    "that is {C:attention}only {C:hearts}hearts{},",
                    "and nothing else",
                    ]]
                }
            },

            p_uma_turf_normal = {
                name = "Turf Pack",
                text = {
                    "Choose {C:attention}#1#{} of up to",
                    "{C:attention}#2# {C:uma_turf}Turf{}-related playing",
                    "cards to add to your deck",
                },
            },

            p_uma_turf_jumbo = {
                name = "Jumbo Turf Pack",
                text = {
                    "Choose {C:attention}#1#{} of up to",
                    "{C:attention}#2# {C:uma_turf}Turf{}-related playing",
                    "cards to add to your deck",
                },
            },

            p_uma_turf_mega = {
                name = "Mega Turf Pack",
                text = {
                    "Choose {C:attention}#1#{} of up to",
                    "{C:attention}#2# {C:uma_turf}Turf{}-related playing",
                    "cards to add to your deck",
                },
            },

            uma_wealth = {
                name = "Wealth",
                text = {
                    "Gives {C:money}$#1#{} when scored",
                    "If card doesn't score next",
                    "blind, sticker {C:attention}disappears{}"
                },
            },
        }
    },

    misc = {
        challenge_names = {
            c_uma_unstable_income = "(un)Stable Income",
            c_uma_horse = "Choose your Uma!",
            c_uma_all_horses = "ALL the horses",
        },

        v_text = {
            ch_c_unstable_income_loc1 = {
               "At the end of the shop, if you have {C:attention}$"
               ..(SMODS.Challenge and SMODS.Challenge.obj_table.c_uma_unstable_income.rules.custom[1].value[1] or "nil")..
               "{} or more,"
            },
            ch_c_unstable_income_loc2 = {
                "lose {C:attention}"
                ..(SMODS.Challenge and SMODS.Challenge.obj_table.c_uma_unstable_income.rules.custom[1].value[2] or "nil")..
                "%{} and create a random {C:uma_rainbow}Uma{} joker {C:inactive}(must have room){}"
            }
        },

        dictionary = {
            a_chips="+#1#",
            a_chips_minus="-#1#",
            a_hands="+#1# Hands",
            a_handsize="+#1# Hand Size",
            a_handsize_minus="-#1# Hand Size",
            a_mult="+#1# Mult",
            a_mult_minus="-#1# Mult",
            a_remaining="#1# Remaining",
            a_sold_tally="#1#/#2# Sold",
            a_xmult="X#1# Mult",
            a_xmult_minus="-X#1# Mult",
            uma_yuri="Yuri!",
            uma_oguri="Yummy!",
            uma_oguri_hungry="Hungry",
            uma_oguri_full="Full!",
            uma_twin_moon="Moon(s)",
            uma_bakushin1="Bakushin!",
            uma_bakushin2="Bakushinshi-n!",
            uma_bakushin3="Ba-...",
            uma_mult_pot="Potential Mult",
            uma_mambo_chips="More chips!",
            uma_mambo_mult="More Mult!",
            uma_mambo_xmult="More xMult!",
            uma_fuku_good = "Good fortune!",
            uma_fuku_bad = "Bad fortune...",
            uma_not_pure = "Not pure!",
            uma_not_aligned = "Not aligned!",
            uma_spread = "Spread!",
            uma_bloom = "Bloom!",
            uma_twin_turbo_trigger = 'Upgrade + Level Up!',
            uma_mini = 'Blind reduced!',
            uma_trigger_added ="+1 Trigger!",
            uma_round_singular = "round",
            uma_round_plural = "rounds",
            uma_debuff_singular = "debuff",
            uma_debuff_plural = "debuffs",
            uma_left = "left",
            uma_restore = "Restored!",
            uma_lucky_cards = "Lucky cards",
            uma_wealth = "Wealth!",
            uma_doto_boss = "Boss Blinds",
            
            uma_goldship_no_effect = "No effect currently",
            uma_goldship_effect1 = "Flips and shuffles jokers",
            uma_goldship_effect2 = "Debuff faces cards",
            uma_goldship_effect3 = "Lose $1 per card played",
            uma_goldship_effect4 = "All face cards are drawn face down",
            uma_goldship_effect5 = "Debuff Spades",
            uma_goldship_effect6 = "Debuff Hearts",
            uma_goldship_effect7 = "Debuff Clubs",
            uma_goldship_effect8 = "Debuff Diamonds",

            uma_goldship_no_effect_jd = "No effect",
            uma_goldship_effect1_jd = "Flips + shuffles",
            uma_goldship_effect2_jd = "Debuff faces",
            uma_goldship_effect3_jd = "-$1 per card played",
            uma_goldship_effect4_jd = "Face cards face down",
            uma_goldship_effect5_jd = "Debuff Spades",
            uma_goldship_effect6_jd = "Debuff Hearts",
            uma_goldship_effect7_jd = "Debuff Clubs",
            uma_goldship_effect8_jd = "Debuff Diamonds",

            uma_love_1_1 = "Retriggers all",
            uma_love_1_2 = "debuffs all other cards",
            uma_love_1_3 = "Overwrites certain boss blinds",
            uma_love_2_1 = "A playing card",
            uma_love_2_2 = "that is",
            uma_love_2_3 = "only",
            uma_love_2_4 = "Hearts",
            uma_love_2_5 = "and nothing else",

            uma_love_1_1_obsc = "R%%r%%ge%s a%l",
            uma_love_1_2_obsc = "%%%u%%s %l% %th%% %a%d%",
            uma_love_1_3_obsc = "%%%r%%%te% %er%a%n bo%s bl%n%%",
            uma_love_2_1_obsc = "A pl%%i%g c%r%",
            uma_love_2_2_obsc = "th%% %s",
            uma_love_2_3_obsc = "%n%%",
            uma_love_2_4_obsc = "%e%%%s",
            uma_love_2_5_obsc = "a%% n%%%i%% %ls%",

            k_uma_turf_pack = 'Turf Pack',

            uma_tarot_plus = "Tarot+",
            uma_tarot_minus = "Tarot-",
            uma_planet_plus = "Planet+",
            uma_dwarf_planet_plus = "Dwarf Planet+",
            uma_X_planet_plus = "Planet+?",
            uma_twin_moon_plus = "Moon(s)+",
            uma_mambo_cards_loc = "Mambo's things",
            uma_family_tree_loc = "Family Tree",

            b_fuku_cards_cards = "Vanilla+",
            b_uma_ccs_cards = "Uma Assorted",
        },

        labels = {
            uma_wealth = "Wealth"
        },

        poker_hand_descriptions = {
            uma_perfect_pair = {
                "2 pairs of matching suits with different ranks,",
                "may be played with 1 other unscored card"
            }
        },

        poker_hands = {
            uma_perfect_pair = "Perfect Pair"
        }
    }
}

--[[
Gives +1 Mult for every spread and bloom trigger this run (Currently +0 Mult)
Gives +1 Mult for every time a turf card spread or bloomed this run (Currently +0 Mult)
Gives +1 Mult for every time a card has bloomed or spread this run (Currently +0 Mult)
]]